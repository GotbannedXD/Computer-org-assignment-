const express = require('express');
const mysql = require('mysql2/promise');
const path = require('path');
const session = require('express-session');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
  secret: 'winabwangu_secret_key',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false, maxAge: 3600000 } // 1 hour session
}));

// Database Connection Pool
const db = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'winabwangu_db',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// Authentication Middleware
function isAuthenticated(req, res, next) {
  if (req.session && req.session.user) {
    return next();
  }
  return res.status(401).json({ error: 'Unauthorized. Please log in.' });
}

// RBAC Middleware: Admin Only Access
function isAdmin(req, res, next) {
  if (req.session && req.session.user && req.session.user.role === 'admin') {
    return next();
  }
  return res.status(403).json({ error: 'Access denied. Admin privileges required.' });
}

// Root Route Handler (Prevents Auto-Index Loading Loops)
app.get('/', (req, res) => {
  if (req.session && req.session.user) {
    return res.redirect('/index.html');
  }
  return res.redirect('/login.html');
});

// Login Route
app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  try {
    const [rows] = await db.query('SELECT * FROM users WHERE username = ?', [username]);
    if (rows.length === 0 || rows[0].password_hash !== password) {
      return res.status(401).json({ error: 'Invalid username or password' });
    }

    const user = rows[0];
    req.session.user = { id: user.id, username: user.username, role: user.role };
    res.json({ message: 'Login successful', user: req.session.user });
  } catch (err) {
    res.status(500).json({ error: 'Database error: ' + err.message });
  }
});

// Logout Route
app.post('/api/logout', (req, res) => {
  if (req.session) {
    req.session.destroy((err) => {
      if (err) return res.status(500).json({ error: 'Failed to destroy session' });
      res.clearCookie('connect.sid');
      return res.json({ message: 'Logged out successfully' });
    });
  } else {
    res.json({ message: 'Logged out successfully' });
  }
});

// Check Session Status
app.get('/api/me', (req, res) => {
  if (req.session && req.session.user) {
    return res.json({ loggedIn: true, user: req.session.user });
  }
  res.json({ loggedIn: false });
});

// Get Next Transaction ID
app.get('/api/transactions/next-id', isAuthenticated, async (req, res) => {
  try {
    const [rows] = await db.query('SELECT COUNT(*) AS total FROM transactions');
    const count = rows[0].total + 1;
    const nextId = `WB${String(count).padStart(7, '0')}`;
    res.json({ nextId });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Create Transaction
app.post('/api/transactions', isAuthenticated, async (req, res) => {
  const { transaction_id, booth, location, service, amount, income } = req.body;
  try {
    await db.query(
      'INSERT INTO transactions (transaction_id, booth, location, service, amount, income) VALUES (?, ?, ?, ?, ?, ?)',
      [transaction_id, booth, location, service, amount, income]
    );
    res.status(201).json({ message: 'Transaction saved successfully' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to record transaction: ' + err.message });
  }
});

// Get All Transactions (RESTRICTED: Admin Only)
app.get('/api/transactions', isAuthenticated, isAdmin, async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM transactions ORDER BY created_at DESC');
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});