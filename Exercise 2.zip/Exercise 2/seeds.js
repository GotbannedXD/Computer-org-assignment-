const mysql = require('mysql2/promise');

async function seedDatabase() {
  console.log('Seeding Database...');

  try {
    const connection = await mysql.createConnection({
      host: 'localhost',
      user: 'root',
      password: ''
    });

    await connection.query('CREATE DATABASE IF NOT EXISTS winabwangu_db');
    await connection.query('USE winabwangu_db');

    // Create Users Table
    await connection.query(`
      CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE,
        password_hash VARCHAR(255) NOT NULL,
        role ENUM('admin', 'operator') DEFAULT 'operator',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Create Transactions Table
    await connection.query(`
      CREATE TABLE IF NOT EXISTS transactions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        transaction_id VARCHAR(50) NOT NULL UNIQUE,
        booth VARCHAR(50) NOT NULL,
        location VARCHAR(100) NOT NULL,
        service VARCHAR(50) NOT NULL,
        amount DECIMAL(10, 2) NOT NULL,
        income DECIMAL(10, 2) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Clear Old Data
    await connection.query('TRUNCATE TABLE users');
    await connection.query('TRUNCATE TABLE transactions');

    // Seed Admin Account
    await connection.query(`
      INSERT INTO users (username, password_hash, role) 
      VALUES ('misheck', '12345', 'admin')
    `);

    // Seed Field Agent Account
    await connection.query(`
      INSERT INTO users (username, password_hash, role) 
      VALUES ('agent1', 'agent123', 'operator')
    `);

    console.log('Database Seeding Completed Successfully!');
    console.log('Admin Account: misheck / 12345');
    console.log('Agent Account: agent1 / agent123');

    await connection.end();
  } catch (err) {
    console.error('Seeding Error:', err.message);
  }
}

seedDatabase();