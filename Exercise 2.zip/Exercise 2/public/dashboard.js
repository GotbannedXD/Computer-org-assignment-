document.addEventListener('DOMContentLoaded', async () => {
  let pieChartInstance = null;

  const BRAND_COLORS = {
    'MTN Mobile Money': '#FFCC00', // MTN Yellow
    'Airtel Money': '#E60000',    // Airtel Red
    'Zamtel Kwacha': '#008000',   // Zamtel Green
    'Bank Deposit': '#6f42c1'     // Royal Purple
  };

  const DEFAULT_COLORS = ['#1a73e8', '#fd7e14', '#20c997', '#e83e8c', '#6c757d'];

  // Logout Listener
  const logoutBtn = document.getElementById('logoutBtn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', async (e) => {
      e.preventDefault();
      try {
        await fetch('/api/logout', { method: 'POST' });
      } catch (err) {
        console.error('Logout error:', err);
      } finally {
        window.location.href = 'login.html';
      }
    });
  }

  // Admin Session Guard
  const checkAdminSession = async () => {
    try {
      const res = await fetch('/api/me');
      const data = await res.json();

      if (!data.loggedIn) {
        window.location.href = 'login.html';
        return false;
      }

      if (data.user.role !== 'admin') {
        window.location.href = 'index.html';
        return false;
      }

      return true;
    } catch (err) {
      window.location.href = 'login.html';
      return false;
    }
  };

  const isAdmin = await checkAdminSession();
  if (!isAdmin) return;

  // Fetch metrics & render table and pie chart
  const loadDashboardMetrics = async () => {
    try {
      const res = await fetch('/api/transactions');
      if (!res.ok) throw new Error('Failed to fetch transactions');

      const transactions = await res.json();

      const totalVolume = transactions.reduce((sum, t) => sum + parseFloat(t.amount || 0), 0);
      const totalIncome = transactions.reduce((sum, t) => sum + parseFloat(t.income || 0), 0);
      const totalCount = transactions.length;

      const volumeEl = document.getElementById('totalVolume');
      const incomeEl = document.getElementById('totalIncome');
      const countEl = document.getElementById('totalTransactions');

      if (volumeEl) volumeEl.textContent = `ZMW ${totalVolume.toFixed(2)}`;
      if (incomeEl) incomeEl.textContent = `ZMW ${totalIncome.toFixed(2)}`;
      if (countEl) countEl.textContent = totalCount;

      const tableBody = document.getElementById('transactionsTableBody');
      if (tableBody) {
        tableBody.innerHTML = '';

        if (transactions.length === 0) {
          tableBody.innerHTML = '<tr><td colspan="5" style="text-align:center; padding: 1.5rem;">No transactions recorded yet.</td></tr>';
        } else {
          transactions.forEach(t => {
            const row = document.createElement('tr');
            row.innerHTML = `
              <td><strong>${t.transaction_id}</strong></td>
              <td>${t.booth}</td>
              <td>${t.service}</td>
              <td>ZMW ${parseFloat(t.amount).toFixed(2)}</td>
              <td style="color: #28a745; font-weight: bold;">ZMW ${parseFloat(t.income).toFixed(2)}</td>
            `;
            tableBody.appendChild(row);
          });
        }
      }

      // Group Income by Service Provider
      const serviceData = {};
      transactions.forEach(t => {
        const service = t.service || 'Other';
        const income = parseFloat(t.income || 0);
        serviceData[service] = (serviceData[service] || 0) + income;
      });

      const chartLabels = Object.keys(serviceData);
      const chartValues = Object.values(serviceData);

      const sliceColors = chartLabels.map((serviceName, index) => {
        return BRAND_COLORS[serviceName] || DEFAULT_COLORS[index % DEFAULT_COLORS.length];
      });

      const ctx = document.getElementById('servicePieChart');
      if (ctx) {
        if (pieChartInstance) {
          pieChartInstance.destroy();
        }

        pieChartInstance = new Chart(ctx, {
          type: 'pie',
          data: {
            labels: chartLabels.length > 0 ? chartLabels : ['No Data'],
            datasets: [{
              data: chartValues.length > 0 ? chartValues : [1],
              backgroundColor: chartLabels.length > 0 ? sliceColors : ['#e0e0e0'],
              borderWidth: 2,
              borderColor: '#ffffff'
            }]
          },
          options: {
            responsive: true,
            plugins: {
              legend: {
                position: 'bottom',
                labels: {
                  usePointStyle: true,
                  padding: 15,
                  font: { size: 12, weight: 'bold' }
                }
              },
              tooltip: {
                callbacks: {
                  label: function(context) {
                    const label = context.label || '';
                    const value = context.parsed || 0;
                    return ` ${label}: ZMW ${value.toFixed(2)}`;
                  }
                }
              }
            }
          }
        });
      }

    } catch (err) {
      console.error('Error loading dashboard metrics:', err);
    }
  };

  await loadDashboardMetrics();
});