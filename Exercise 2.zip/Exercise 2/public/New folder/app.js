document.addEventListener('DOMContentLoaded', async () => {
  // Logout Handler
  const logoutBtn = document.getElementById('logoutBtn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', async (e) => {
      e.preventDefault();
      try {
        await fetch('/api/logout', { method: 'POST' });
      } catch (err) {
        console.error('Logout failed:', err);
      } finally {
        window.location.href = 'login.html';
      }
    });
  }

  // Session Check
  const checkSession = async () => {
    try {
      const res = await fetch('/api/me');
      const data = await res.json();

      if (!data.loggedIn) {
        window.location.href = 'login.html';
        return false;
      }

      // Hide Dashboard tab for agents
      if (data.user.role !== 'admin') {
        const dashboardLink = document.getElementById('navDashboard');
        if (dashboardLink) {
          dashboardLink.style.display = 'none';
        }
      }

      return true;
    } catch (err) {
      window.location.href = 'login.html';
      return false;
    }
  };

  const isAuth = await checkSession();
  if (!isAuth) return;

  // Auto Generate Next Transaction ID
  const fetchNextId = async () => {
    const idInput = document.getElementById('transaction_id');
    if (!idInput) return;
    try {
      const res = await fetch('/api/transactions/next-id');
      const data = await res.json();
      if (data.nextId) {
        idInput.value = data.nextId;
      }
    } catch (err) {
      console.error('Failed to generate next transaction ID:', err);
    }
  };

  await fetchNextId();

  // Handle Form Submission
  const form = document.getElementById('transactionForm');
  const alertBox = document.getElementById('feedbackAlert');

  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();

      if (alertBox) alertBox.style.display = 'none';

      const submitBtn = form.querySelector('button[type="submit"]');
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.textContent = 'Saving Transaction...';
      }

      const payload = {
        transaction_id: document.getElementById('transaction_id').value,
        booth: document.getElementById('booth').value,
        location: document.getElementById('location').value,
        service: document.getElementById('service').value,
        amount: parseFloat(document.getElementById('amount').value) || 0,
        income: parseFloat(document.getElementById('income').value) || 0
      };

      try {
        const res = await fetch('/api/transactions', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });

        const data = await res.json();

        if (res.ok) {
          if (alertBox) {
            alertBox.className = 'alert alert-success';
            alertBox.textContent = `✅ Success! Transaction ${payload.transaction_id} recorded.`;
            alertBox.style.display = 'block';
          }
          form.reset();
          await fetchNextId();
        } else {
          if (alertBox) {
            alertBox.className = 'alert alert-danger';
            alertBox.textContent = `❌ Error: ${data.error || 'Failed to save transaction.'}`;
            alertBox.style.display = 'block';
          }
        }
      } catch (err) {
        if (alertBox) {
          alertBox.className = 'alert alert-danger';
          alertBox.textContent = '❌ Network error: Unable to connect to server.';
          alertBox.style.display = 'block';
        }
      } finally {
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.textContent = 'Submit Transaction';
        }
      }
    });
  }
});